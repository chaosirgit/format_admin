-- MySQL dump 10.13  Distrib 5.7.26, for Linux (x86_64)
--
-- Host: localhost    Database: radar
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_log`
--

DROP TABLE IF EXISTS `account_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `value` decimal(20,2) DEFAULT '0.00',
  `new_value` decimal(20,2) DEFAULT '0.00',
  `info` varchar(255) DEFAULT '',
  `type` tinyint(4) unsigned DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_log`
--

LOCK TABLES `account_log` WRITE;
/*!40000 ALTER TABLE `account_log` DISABLE KEYS */;
INSERT INTO `account_log` VALUES (2,1,-200.00,0.00,'后台调节余额:',1,1561379310);
/*!40000 ALTER TABLE `account_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) DEFAULT '',
  `password` varchar(255) DEFAULT '',
  `role_id` tinyint(1) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='管理员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','a79776e6134eae05bc1d5ccad2daecda',1,0);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_action`
--

DROP TABLE IF EXISTS `admin_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_module_id` int(11) DEFAULT '0' COMMENT '权限模型表id',
  `name` varchar(60) DEFAULT '',
  `action` varchar(60) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COMMENT='权限控制表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_action`
--

LOCK TABLES `admin_action` WRITE;
/*!40000 ALTER TABLE `admin_action` DISABLE KEYS */;
INSERT INTO `admin_action` VALUES (1,1,'管理员页面','admin_user'),(2,1,'管理员列表','admin_user_list'),(3,1,'管理员添加/编辑','admin_add'),(4,1,'管理员删除','admin_del'),(5,1,'角色管理页面','admin_role'),(6,1,'角色管理列表','admin_role_list'),(7,1,'角色管理添加','admin_role_add'),(8,1,'角色管理删除','admin_role_del'),(9,1,'角色权限修改','permission'),(10,2,'用户页面','user'),(11,2,'用户列表','user_list'),(12,2,'用户日志页面','user_log'),(13,2,'用户日志列表','log_list'),(14,3,'基础数据设置','setting'),(15,4,'新闻分类页面','news_category'),(16,4,'新闻分类列表','news_category_list'),(17,4,'新闻分类添加/编辑','news_category_add'),(18,4,'新闻分类删除','news_category_del'),(19,4,'新闻页面','news'),(20,4,'新闻列表','news_list'),(21,4,'新闻添加/编辑','news_add'),(22,4,'新闻删除','news_del'),(23,5,'后台首页','index'),(24,5,'后台展示页','main'),(25,5,'后台登出','logout'),(26,1,'管理员操作日志列表','admin_operate');
/*!40000 ALTER TABLE `admin_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_module`
--

DROP TABLE IF EXISTS `admin_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT '',
  `module` varchar(60) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='权限模型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_module`
--

LOCK TABLES `admin_module` WRITE;
/*!40000 ALTER TABLE `admin_module` DISABLE KEYS */;
INSERT INTO `admin_module` VALUES (1,'管理权限','permission'),(2,'用户管理','user'),(3,'基础数据管理','setting'),(4,'新闻管理','news'),(5,'后台管理','admin');
/*!40000 ALTER TABLE `admin_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_operate`
--

DROP TABLE IF EXISTS `admin_operate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_operate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT '0',
  `role_id` int(11) DEFAULT '0',
  `action_id` int(11) DEFAULT '0',
  `result_msg` varchar(255) DEFAULT '',
  `create_time` int(11) DEFAULT '0',
  `relation_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='操作日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_operate`
--

LOCK TABLES `admin_operate` WRITE;
/*!40000 ALTER TABLE `admin_operate` DISABLE KEYS */;
INSERT INTO `admin_operate` VALUES (1,1,1,9,'修改成功',1561378252,0),(2,1,1,0,'操作成功',1561379133,0),(3,1,1,0,'操作成功',1561379310,0),(4,1,1,9,'修改成功',1561385329,0);
/*!40000 ALTER TABLE `admin_operate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role`
--

DROP TABLE IF EXISTS `admin_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT NULL,
  `is_super` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='管理员角色表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role`
--

LOCK TABLES `admin_role` WRITE;
/*!40000 ALTER TABLE `admin_role` DISABLE KEYS */;
INSERT INTO `admin_role` VALUES (1,'超级管理员',1);
/*!40000 ALTER TABLE `admin_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_permission`
--

DROP TABLE IF EXISTS `admin_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `admin_action_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COMMENT='角色权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_permission`
--

LOCK TABLES `admin_role_permission` WRITE;
/*!40000 ALTER TABLE `admin_role_permission` DISABLE KEYS */;
INSERT INTO `admin_role_permission` VALUES (26,1,1),(27,1,2),(28,1,3),(29,1,4),(30,1,5),(31,1,6),(32,1,7),(33,1,8),(34,1,9),(35,1,26),(36,1,10),(37,1,11),(38,1,12),(39,1,13),(40,1,14),(41,1,15),(42,1,16),(43,1,17),(44,1,18),(45,1,19),(46,1,20),(47,1,21),(48,1,22),(49,1,23),(50,1,24),(51,1,25);
/*!40000 ALTER TABLE `admin_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT '0' COMMENT '新闻分类id',
  `title` varchar(255) DEFAULT '',
  `content` longtext,
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `news_id_index` (`id`),
  KEY `news_category_id_index` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='新闻表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news_category`
--

DROP TABLE IF EXISTS `news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `news_category_id_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='新闻分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news_category`
--

LOCK TABLES `news_category` WRITE;
/*!40000 ALTER TABLE `news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `news_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(60) DEFAULT '',
  `value` varchar(1000) DEFAULT '',
  `comment` varchar(60) DEFAULT '' COMMENT '说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `upload`
--

DROP TABLE IF EXISTS `upload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `key` varchar(255) DEFAULT '',
  `ext` varchar(10) DEFAULT '',
  `file_size` int(11) DEFAULT '0',
  `file_name` varchar(255) DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `is_admin` tinyint(4) DEFAULT '0',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COMMENT='上传表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `upload`
--

LOCK TABLES `upload` WRITE;
/*!40000 ALTER TABLE `upload` DISABLE KEYS */;
INSERT INTO `upload` VALUES (1,1,'http://39.107.142.181/storage/Imzk90VouuloHBX556bSbTSIAUw0YrKBCIilA7Fy.png','png',45899,'派好.png','http://39.107.142.181/storage/Imzk90VouuloHBX556bSbTSIAUw0YrKBCIilA7Fy.png',1,1561384587),(2,1,'http://39.107.142.181/storage/tYJQvAknP5Xam7EDdHhEInlcEr28qbssEg8NrlGH.png','png',45899,'派好.png','http://39.107.142.181/storage/tYJQvAknP5Xam7EDdHhEInlcEr28qbssEg8NrlGH.png',1,1561384604),(3,1,'http://39.107.142.181/storage/TPfXUAJNrhqLMgGSrRG5H6ybVERGHhIyuqD5QIIj.png','png',56848,'欧总节点挖矿.png','http://39.107.142.181/storage/TPfXUAJNrhqLMgGSrRG5H6ybVERGHhIyuqD5QIIj.png',1,1561384604),(4,1,'http://39.107.142.181/storage/EYZMATCJIWXXO80jZgVE6nECNMU6AzbsGVlWn7As.png','png',45899,'派好.png','http://39.107.142.181/storage/EYZMATCJIWXXO80jZgVE6nECNMU6AzbsGVlWn7As.png',1,1561385218);
/*!40000 ALTER TABLE `upload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(60) DEFAULT '',
  `open_id` varchar(60) DEFAULT '',
  `nickname` varchar(255) DEFAULT '',
  `avatar` varchar(255) DEFAULT '',
  `radar_username` varchar(255) DEFAULT '',
  `radar_password` varchar(1000) DEFAULT '',
  `radar_pay_password` varchar(1000) DEFAULT '',
  `radar_email` varchar(60) DEFAULT '',
  `create_time` int(11) DEFAULT '0',
  `gender` tinyint(4) DEFAULT '0',
  `radar_validated` tinyint(4) DEFAULT '0',
  `parent_id` int(11) DEFAULT '0',
  `password` varchar(255) DEFAULT '',
  `balance` decimal(20,2) DEFAULT '0.00',
  `integral` int(11) DEFAULT '0',
  `mobile` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_uid_uindex` (`uid`),
  UNIQUE KEY `users_mobile_uindex` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'520b2b20-9343-11e9-b4c4-5bf3280290a9','onZnj5LARqJm9iMv4361xeyQBMcw','3','https://wx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEJWlJwbnOaOFMnE83EZ2eRaFOsdicpS5L2FYTefufjTF70cwe6LJ4OKalicLtNhs6vLWlKTcvKpnLDQ/132','moment05','eyJpdiI6IkE1aWdTXC9GNmRqRU1zSVNJMkZrbTFRPT0iLCJ2YWx1ZSI6InM3RVE0SkVqbzVsc3NJV0VFOUF4S0E9PSIsIm1hYyI6ImM3NWMzMmI0NTJkMTBiYjJiMjNiNDc2ZjI2ZjQ3NzNiNjgxZDZmMTU3YTFhZDgwZGI0ZWY0YTJjNjJkYWRkY2QifQ==','eyJpdiI6ImQxaEpqNWJ2OGc3U2ZaUUZEK0w3clE9PSIsInZhbHVlIjoiZUlKbDRiNlRQSnQ2ZnRKdkpWVlQ5QT09IiwibWFjIjoiODFhMGVlNzMzMjdkOWIzNzI1YTdmZmVhNzc0MmRkMDRhMWUyYzUxNzg2ZDJkZDQ1ZWUzOTc5M2JjODkyZGMxMyJ9','13838920869@163.com',1561025296,1,0,0,'',0.00,0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-24 22:09:28
